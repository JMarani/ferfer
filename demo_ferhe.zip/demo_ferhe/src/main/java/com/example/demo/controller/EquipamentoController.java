
package com.example.demo.controller;

import com.example.demo.model.Equipamento;
import com.example.demo.service.EquipamentoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/equipamentos")
public class EquipamentoController {

    private final EquipamentoService service;

    public EquipamentoController(EquipamentoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Equipamento> listarTodos() {
        return service.listarTodos();
    }

    @PatchMapping("/{id}/inativar")
    public Equipamento inativarEquipamento(@PathVariable Long id) {
        return service.inativarEquipamento(id);
    }
}
