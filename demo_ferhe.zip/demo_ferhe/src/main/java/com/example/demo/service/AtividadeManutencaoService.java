
package com.example.demo.service;

import com.example.demo.model.AtividadeManutencao;
import com.example.demo.repository.AtividadeManutencaoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class AtividadeManutencaoService {

    private final AtividadeManutencaoRepository repository;

    public AtividadeManutencaoService(AtividadeManutencaoRepository repository) {
        this.repository = repository;
    }

    public List<AtividadeManutencao> listarTodas() {
        return repository.findAll();
    }

    public List<AtividadeManutencao> consultarPorData(LocalDate dataRealizacao) {
        return repository.findByDataRealizacao(dataRealizacao);
    }

    public List<AtividadeManutencao> consultarPorEquipamento(Long equipamentoId) {
        return repository.findByEquipamentoId(equipamentoId);
    }

    public List<AtividadeManutencao> consultarPorTipo(String tipoManutencao) {
        return repository.findByTipoManutencao(tipoManutencao);
    }
}
