
package com.example.demo.service;

import com.example.demo.model.Equipamento;
import com.example.demo.repository.EquipamentoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EquipamentoService {

    private final EquipamentoRepository repository;

    public EquipamentoService(EquipamentoRepository repository) {
        this.repository = repository;
    }

    public List<Equipamento> listarTodos() {
        return repository.findAll();
    }

    public Equipamento inativarEquipamento(Long id) {
        Equipamento equipamento = repository.findById(id).orElseThrow(() -> new RuntimeException("Equipamento não encontrado."));
        equipamento.inativar();
        return repository.save(equipamento);
    }
}
