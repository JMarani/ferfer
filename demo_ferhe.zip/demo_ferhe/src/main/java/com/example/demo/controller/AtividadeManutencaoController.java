
package com.example.demo.controller;

import com.example.demo.model.AtividadeManutencao;
import com.example.demo.service.AtividadeManutencaoService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/manutencoes")
public class AtividadeManutencaoController {

    private final AtividadeManutencaoService service;

    public AtividadeManutencaoController(AtividadeManutencaoService service) {
        this.service = service;
    }

    @GetMapping
    public List<AtividadeManutencao> listarTodas() {
        return service.listarTodas();
    }

    @GetMapping("/data")
    public List<AtividadeManutencao> consultarPorData(@RequestParam String data) {
        return service.consultarPorData(LocalDate.parse(data));
    }

    @GetMapping("/equipamento/{id}")
    public List<AtividadeManutencao> consultarPorEquipamento(@PathVariable Long id) {
        return service.consultarPorEquipamento(id);
    }

    @GetMapping("/tipo")
    public List<AtividadeManutencao> consultarPorTipo(@RequestParam String tipo) {
        return service.consultarPorTipo(tipo);
    }
}
